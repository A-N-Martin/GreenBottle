/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

import java.util.*;
/**
 *
 * @author Allmightyme
 */
    // La classe Grille contient la grille de Sudoku sous un format tableau [9][9]
    public class Grille {
        int [][] GrilleJeu = new int [9][9];
    

    
    public Grille (ArrayList<Integer> cases){
        cases.forEach((c) -> {
            int numero = c % 10;
            int ligne = (c/100) % 10;
            int colonne = (c/10) % 10 ;
            GrilleJeu[ligne][colonne] = numero;
        });
    }

    public int getValeur(int ln, int col){
        int valeur;
        valeur = GrilleJeu[ln][col];
        return valeur;
    }

    // peutEtreAjoute permet de vérifier si la valeur
    // donnée à la fonction existe déjà sur la ligne, la colonne ou le bloc et 
    // retourne un vrai ou faux.
    
    public boolean peutEtreAjoute(int valeur, int ligne, int colonne){
        boolean AjoutImpossible = false;
            for (int i = 0 ; i<9 ; i++){
                if (this.getValeur(ligne,i) == valeur){
                    AjoutImpossible = true;
                }
            }
            for (int i = 0 ; i<9 ; i++){
                if (this.getValeur(i, colonne) == valeur){
                AjoutImpossible = true;
                }
            }
            int limiteLigneBas = (ligne / 3) * 3 ;
            int limiteLigneHaut = limiteLigneBas + 3;
            int limiteColBas = (colonne / 3) * 3;
            int limiteColHaut = limiteColBas + 3;
            for (int l = limiteLigneBas; l < limiteLigneHaut; l++){
                for (int c = limiteColBas; c < limiteColHaut; c++){
                    if (this.getValeur(l, c) == valeur){
                        AjoutImpossible = true;
                    }
                }
            }
        return AjoutImpossible;
    }
        
    
    // AjoutCase permet d'ajouter un valeur à la grille dans la ligne et la 
    // colonne donnée
    public void AjoutCase(int ligne, int colonne, int valeur){
        GrilleJeu[ligne][colonne] = valeur;
    }
        
    // Imprimmer Grille permet d'imprimer les valeurs de la grille sous un format
    // facile d'utilisation pour jouer au Sudoku.
    public void imprimerGrille(){
        for (int ln = 0; ln < 9 ; ln++){
            if ((ln % 3) == 0){
                System.out.println("_____________");
        }
            for (int col = 0; col < 9 ; col++){
                if ((col % 3) == 0){
                    System.out.print("|");
                }
                System.out.print(GrilleJeu[ln][col]);
                if (col == 8){
                    System.out.println("|");
                }
            }
            if ( ln == 8){
                System.out.println("___________________");
            }
        }
        
    }
    
    //grilleToArrayList() permet de changer la grille dans un format ArrayList
    //pour pouvoir être fourni au menu AfficherMenu2().
    
    public ArrayList<Integer> grilleToArrayList(){
            ArrayList<Integer> cases = new ArrayList<>();
        for (int ln = 0; ln < 9 ; ln++){
            for (int col = 0; col < 9; col++){

                    cases.add(ln*100 + col * 10 +this.getValeur(ln, col));                    
                
            }
        }
        return cases;
    }
    
    }
