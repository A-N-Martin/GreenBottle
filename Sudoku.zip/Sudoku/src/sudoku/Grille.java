/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

import java.util.*;
/**
 *
 * @author Allmightyme
 */
    // La classe Grille contient la grille de Sudoku sous un format tableau [9][9]
    public class Grille {
        int [][] GrilleJeu = new int [9][9];
    
        
    // Deux constructeur existe, un constructeur permet de créer une instance Grille
    // sans lui donner de valeurs, la deuxième utilise un ArrayList d'objet Case
    // pour créer l'object Grille.
    public Grille (){

    }
 
    
    public Grille (ArrayList<Case> cases){
        cases.forEach((c) -> {
            GrilleJeu[c.ligne][c.colonne] = c.valeur;
        });
    }

    public int getValeur(int ln, int col){
        int valeur;
        valeur = GrilleJeu[ln][col];
        return valeur;
    }

    // estSurLigne, estSurColonne et estDansBloc permet de vérifier si la valeur
    // donnée à la fonction existe déjà sur la ligne, la colonne ou le bloc et 
    // retourne un vrai ou faux.
    public boolean estSurLigne(int valeur, int ligne){
        boolean Surligne = false;
        for (int i = 0 ; i<9 ; i++){
            if (this.getValeur(ligne,i) == valeur){
                Surligne = true;
            }
        }
        return Surligne;
        }
    
    public boolean estSurColonne(int valeur, int colonne){
        boolean Surcolonne = false;
        for (int i = 0 ; i<9 ; i++){
            if (this.getValeur(i, colonne) == valeur){
                Surcolonne = true;
            }
        }
        return Surcolonne;
        }
    
    public boolean estDansLeBloc(int valeur, int ligne, int colonne){
        boolean DansLeBloc = false;
        int limiteLigneBas = (ligne / 3) * 3 ;
        int limiteLigneHaut = limiteLigneBas + 3;
        int limiteColBas = (colonne / 3) * 3;
        int limiteColHaut = limiteColBas + 3;
            for (int l = limiteLigneBas; l < limiteLigneHaut; l++){
                for (int c = limiteColBas; c < limiteColHaut; c++){
                    if (this.getValeur(l, c) == valeur){
                        DansLeBloc = true;
                    }
                }
            }
        
        return DansLeBloc;
    }
    
    // AjoutCase permet d'ajouter un valeur à la grille dans la ligne et la 
    // colonne donnée
    public void AjoutCase(int ligne, int colonne, int valeur){
        GrilleJeu[ligne][colonne] = valeur;
    }
        
    // Imprimmer Grille permet d'imprimer les valeurs de la grille sous un format
    // facile d'utilisation pour jouer au Sudoku.
    public void imprimerGrille(){
        for (int ln = 0; ln < 9 ; ln++){
            if ((ln % 3) == 0){
                System.out.println("_____________");
        }
            for (int col = 0; col < 9 ; col++){
                if ((col % 3) == 0){
                    System.out.print("|");
                }
                System.out.print(GrilleJeu[ln][col]);
                if (col == 8){
                    System.out.println("|");
                }
            }
            if ( ln == 8){
                System.out.println("___________________");
            }
        }
        
    }
    
    //grilleToArrayList() permet de changer la grille dans un format ArrayList
    //pour pouvoir être fourni au menu AfficherMenu2().
    
    public ArrayList<Case> grilleToArrayList(){
            ArrayList<Case> cases = new ArrayList<>();
        for (int ln = 0; ln < 9 ; ln++){
            for (int col = 0; col < 9; col++){

                    cases.add(new Case(ln,col,this.getValeur(ln, col)));                    
                
            }
        }
        return cases;
    }
    
    }
