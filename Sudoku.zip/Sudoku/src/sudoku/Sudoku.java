/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

/**
 *
 * @author Allmightyme
 */

import java.util.*;
import java.io.*;

public class Sudoku {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     // La fonction AfficherMenuDébut permet de débuter le programme. Le programme
     // peut seulement être arrêté en choisissant "Quitter" une fois le 
     // programme commencé. Les fonctions majeurs sont décrites sous leurs
     // classes respectives.
        ChoixMenu.AfficherMenuDébut();
       
                
    }
}

    

