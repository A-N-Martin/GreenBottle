/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

/**
 *
 * @author Allmightyme
 */


// Cette classe est créé pour être utilisé dans un ArrayList qui lui est utilisé
// pour créer la grille de jeu du Sudoku.
public class Case {
    int ligne;
    int colonne;
    int valeur;
    
    // Le constructeur de la classe Case permet de créer un individu Classe. 
    // L'individu doit contenir la ligne, la colonne et la valeur dès qu'il est construit
    
    public Case (int ligne, int colonne, int valeur){
        this.ligne = ligne;
        this.colonne = colonne;
        this.valeur = valeur;
    }
    
    // Les fonction get et set permettent d'obtenir chaque élément d'une instance de
    // Case créée. Par contre, elles ne sont pas utilisées dans le programme.
    
    public int getLigne(){
        int ln = this.ligne;
        return ln;
    }
    
    public int getColonne(){
        int col = this.colonne;
        return col;
    }
    
    public int getValeur(){
        int val = this.valeur;
        return val;
    }
    
    public void setValeur(int val){
        this.valeur = val;
    }
    
    public void setLigne(int ln){
        this.ligne = ln;
    }
    
    public void setColonne(int col){
        this.colonne = col;
    }
}

